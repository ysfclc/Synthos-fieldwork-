# SynthOS Fieldwork — Product change log

## 3.0.0 — Conversations, Work Graph and Runtime Boundaries

- Added persistent AI conversations and messages to the encrypted workspace schema (schema version 3); version 1 and 2 backups remain importable.
- Added conversation creation, search, rename, provider/model metadata, transcript import, and Android text-share capture. Imported content is explicitly labelled as user-provided source.
- Added a single-model prompt path for conversational response and structured extraction, with explicit per-request consent when using a remote provider.
- Added typed persistent entities, properties, source excerpts, first-class relationships, duplicate-name protection, review/approval/rejection, editing, relationship linking, and evidence-preserving merges with archived source records.
- Added source-grounded outcome extraction. Model responses are parsed as data; only proposals with exact excerpts found in the source conversation are accepted into the review queue.
- Added persistent work jobs and step traces, including interruption recovery, visible evidence/details, failed states, and waiting-for-user review state.
- Added a deterministic app-runtime follow-up workflow that creates a typed TASK entity from an approved entity, links it to source context, and records a verified job trace. The operation refuses duplicates, archived sources and incomplete runtime capabilities.
- Added explicit runtime descriptors for native SynthOS workspaces and a separate browser runtime. Browser capabilities cannot be inferred by native app capabilities and vice versa.
- Reorganized bottom navigation around Home, Chats, Work, Browser, and More; Council, Models, and Settings remain available from More and Home.
- Kept the original package ID and changed the application version to 3.0.0 / versionCode 3.
- Extended workspace backups with conversations, messages, entities, relationships and jobs; added size limits and schema validation for the new records.
- Added unit tests for source-evidence checks, v3 workspace round-trip, interrupted job recovery, runtime capability separation and the follow-up-task workflow.

### Verification boundary

A full Android Gradle build and test run could not be completed in this environment because the Gradle 8.13 distribution download failed with DNS resolution errors for `services.gradle.org`. The project source and tests have been updated, but APK compilation and on-device behavior are not verified here. The repository's GitHub Actions workflow must pass before this package should be treated as build-verified.

## 2.1.0 — Apps workspace direction

- Promoted the former Tools destination to an Apps destination during the first implementation slice.
- Reframed the browser surface as an embedded WebView with quick links to supported web services.
- Clarified that browser interactions are bounded and do not imply arbitrary native app control.

## 2.0.0 — Council and local model runtime

- Added five traceable model execution patterns, a local-model manager, optional OpenAI-compatible HTTPS configuration, source evidence, workspace backup/restore and browser research tools.
- Retained human ownership of final decisions and per-run consent for remote inference.
