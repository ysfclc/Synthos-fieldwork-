## 3.1.0 — Frontier browser workflows and source-grounded outcomes

- Added a browser-backed frontier consultation workflow using the real ChatGPT, Claude, Gemini, Grok, DeepSeek, Perplexity, Le Chat and Copilot websites inside the separate visible browser runtime. Login and site challenges remain user-controlled; unsupported controls pause for takeover instead of blindly resending.
- Clarified the workflow modes: Consult and compare sends independent prompts through each selected site before local output mapping; Critique and refine explicitly passes earlier captured outputs to later models.
- Reframed local AI as the orchestrator: it structures intent, preserves constraints, maps frontier outputs, and proposes typed outcomes instead of acting as the domain authority.
- Captured each detected frontier response as evidence and a persistent `FRONTIER_RESPONSE` entity, linked it to the consultation summary/collection, and verified outcome persistence before reporting job success.
- Added a source-grounded outcome extraction step for projects, tasks, decisions, knowledge, people, organizations and artifacts. Exact excerpts are validated against captured provider responses and proposals remain pending human review.
- Improved manual-send recovery to detect a visibly submitted prompt before retrying, reducing duplicate submissions when a provider's Send control is unsupported. Each new provider step also returns to the configured entry/new-chat route instead of reusing a page solely because its host matches.
- Fixed interruption recovery activity wording so it matches singular/plural task and job counts; added coverage for interrupted jobs and critique/compare prompt behavior.
- Pinned the project Gradle bootstrap to 8.14.6 and incremented the app to version 3.1.0 / versionCode 4.

### Verification boundary

The requested `testDebugUnitTest lintDebug assembleDebug` command was attempted in this environment, but a local Gradle installation and Android SDK are not available, and downloading the Gradle distribution is blocked by DNS resolution for `services.gradle.org`. Browser JavaScript syntax and selected pure-Kotlin prompt code are checked independently; the full Android compilation, tests, lint and APK are **not verified here**. The repository CI workflow must pass before release.

# SynthOS Fieldwork — Product change log

## 3.0.0 — Conversations, Work Graph and Runtime Boundaries

- Added persistent AI conversations and messages to the encrypted workspace schema (schema version 3); version 1 and 2 backups remain importable.
- Added conversation creation, search, rename, provider/model metadata, transcript import, and Android text-share capture. Imported content is explicitly labelled as user-provided source.
- Added a single-model prompt path for conversational response and structured extraction, with explicit per-request consent when using a remote provider.
- Added typed persistent entities, properties, source excerpts, first-class relationships, duplicate-name protection, review/approval/rejection, editing, relationship linking, and evidence-preserving merges with archived source records.
- Added source-grounded outcome extraction. Model responses are parsed as data; only proposals with exact excerpts found in the source conversation are accepted into the review queue.
- Added persistent work jobs and step traces, including interruption recovery, visible evidence/details, failed states, and waiting-for-user review state.
- Added a deterministic app-runtime follow-up workflow that creates a typed TASK entity from an approved entity, links it to source context, and records a verified job trace. The operation refuses duplicates, archived sources and incomplete runtime capabilities.
- Added explicit runtime descriptors for native SynthOS workspaces and a separate browser runtime. Browser capabilities cannot be inferred by native app capabilities and vice versa.
- Reorganized bottom navigation around Home, Chats, Work, Browser, and More; Council, Models, and Settings remain available from More and Home.
- Kept the original package ID and changed the application version to 3.0.0 / versionCode 3.
- Extended workspace backups with conversations, messages, entities, relationships and jobs; added size limits and schema validation for the new records.
- Added unit tests for source-evidence checks, v3 workspace round-trip, interrupted job recovery, runtime capability separation and the follow-up-task workflow.

### Verification boundary

At the 3.0.0 release point, the Android Gradle build and on-device behavior were not verified in the editing environment. See the 3.1.0 verification boundary for the latest build-attempt status.

## 2.1.0 — Apps workspace direction

- Promoted the former Tools destination to an Apps destination during the first implementation slice.
- Reframed the browser surface as an embedded WebView with quick links to supported web services.
- Clarified that browser interactions are bounded and do not imply arbitrary native app control.

## 2.0.0 — Council and local model runtime

- Added five traceable model execution patterns, a local-model manager, optional OpenAI-compatible HTTPS configuration, source evidence, workspace backup/restore and browser research tools.
- Retained human ownership of final decisions and per-run consent for remote inference.
