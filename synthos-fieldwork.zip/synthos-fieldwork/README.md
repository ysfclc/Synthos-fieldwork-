# SynthOS 2.0 — Council and Local Model Runtime

SynthOS is a private, on-device workspace for **traceable collaboration between models**. It is not primarily a browser. The browser is one source-gathering tool; the core workflow is to give a task to selected model roles, retain each contribution, preserve disagreement, synthesize the evidence, and record the human's final decision.

## What is in this build

### Council

Five execution patterns are available:

- **Independent panel:** selected models answer from the same task independently; a synthesizer compares their answers.
- **Sequential handoff:** each selected model receives the task and the previous stage's output.
- **Draft + critic:** a draft is challenged by selected critics before synthesis.
- **Debate:** proposal, challenge, revision, and synthesis remain separate turns.
- **Specialist panel:** different roles focus on research, skeptical review, implementation, and risk.

The run log records model/role, request, response, status, and duration for every turn. Failed turns remain visible. The synthesis is not treated as a vote and does not erase disagreement. The user can record an accepted conclusion, rejected claim, or next action. Council history is retained in the encrypted local workspace and included in JSON workspace backups. Older schema-version-1 backups remain importable.

### Local models

The model manager can download and install compatible `.litertlm` artifacts on demand, show download progress, cancel a download, remove installed weights, or import a compatible `.litertlm` file from Android storage. Model weights live in private app storage and are **not included in the APK**. No model is downloaded until the user explicitly taps an install option.

Built-in choices:

| Model | Approximate file size | Intended use |
|---|---:|---|
| Qwen3 0.6B INT8 | about 586 MB | Recommended first install for lightweight offline analysis |
| Gemma 4 E2B mixed quantized | about 2.6 GB | Larger-capability option; install only with ample storage and RAM |

These options use the standard CPU/GPU-compatible `.litertlm` artifacts named in Google's LiteRT-LM Android guidance, rather than chip-specific NPU or web builds. [Google's model setup guidance](https://developer.android.com/agents/skills/device-ai/litert/litert-lm/references/get-a-model) · [Qwen3 0.6B LiteRT card](https://huggingface.co/litert-community/Qwen3-0.6B) · [Gemma 4 E2B LiteRT card](https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm). Qwen's published 0.6B phone benchmarks show roughly 2.7–4.3 GB peak memory depending on device and backend; the file being small does not mean every phone can run it. Gemma 4's published benchmark on one flagship Android device reports about 1.7 GB CPU memory or 676 MB GPU memory, but results vary by handset. The app checks available storage before downloading; it cannot reliably predict available runtime RAM in advance. The first answer after loading a model may take longer while its weights initialize. The implementation tries the GPU backend first and falls back to CPU when GPU initialization or execution fails.

This build uses Google's [LiteRT-LM Android API](https://developer.android.com/agents/skills/device-ai/litert/litert-lm/skill). Import expects a `.litertlm` artifact compatible with that runtime. GGUF files and an Ollama model directory are not directly supported by this engine.

### Optional remote endpoint

An OpenAI-compatible chat-completions endpoint can be configured with an HTTPS base URL and model identifier. A remote endpoint is not required for local-only operation. The optional API key is encrypted with Android Keystore and stored separately from workspace backups. Remote use is gated twice: a remote model must be selected and the user must explicitly approve uploading the prompt and selected evidence for that **individual Council run**. The remote API adapter does not support arbitrary HTTP endpoints; HTTPS is required.

### Supporting tools

The previous browser, user-visible page capture, link extraction, tasks, evidence viewer, secure workspace vault, backup/restore, and device lock remain available under **Tools**. They support the Council workflow rather than defining the whole product.

## Privacy and data behavior

- No model weights ship inside the APK.
- Local inference runs on the Android device after a compatible model is installed.
- The task prompt and attached evidence remain local unless a remote model is selected and the per-run upload permission is checked.
- Remote provider credentials are stored in a separate encrypted file protected by Android Keystore and are not included in JSON workspace exports.
- The workspace uses AES-256-GCM with a key held by Android Keystore.
- Workspace JSON exports are readable, user-controlled files; choose a trusted destination and protect exported files yourself.
- There is no built-in product telemetry or third-party analytics SDK.
- Web pages and model outputs are untrusted content. Council roles do not grant external-action authority; the app does not claim that a model actually performed an external action just because its text says so.

## Build

- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.13
- Android Gradle Plugin 8.13.0
- Kotlin 2.4.0

Build locally with:

```bash
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug
```

The debug APK output is:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The repository's GitHub Actions workflow performs the same test/lint/build sequence and uploads the APK as an artifact. It expects `synthos-fieldwork.zip` at repository root, with this directory structure inside the ZIP:

```text
synthos-fieldwork/
  settings.gradle.kts
  build.gradle.kts
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
```

The current build package is `app.synthos.fieldwork` (debug package suffix `.debug`) and version `2.0.0`.

## Verification status

The source package was edited in this environment, but a complete Android Gradle compile was **not run here** because Gradle/Android SDK dependencies could not be downloaded in this environment. The first thing to verify on GitHub is `assembleDebug`; only a successful workflow run is proof that the APK compiles on the build runner. After compilation, the local model downloader and inference need physical-device testing on the target phone. Model downloads require internet the first time; inference can then run offline.

## Deliberate limits in this build

This is the SynthOS Council + local-model slice, not a claim that the entire longer-term ME operating environment is finished. The app does not yet include hands-free voice, a broad set of provider-specific SDK adapters, multi-device sync, automatic ingestion of coding-session histories, or a general-purpose agent that can autonomously operate arbitrary browser/API/CLI workflows. The browser task engine remains a bounded supporting tool. A single installed model can run different roles, but those outputs are not independent model opinions; install multiple distinct models or configure a remote provider when you want real model diversity.
