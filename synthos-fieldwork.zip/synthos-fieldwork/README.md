# SynthOS Fieldwork 1.0.0

A private, Android-native browser automation workspace. Sign in to websites yourself inside the app, run a small set of inspectable browser tasks, and save source-backed observations into an encrypted local evidence ledger.

## What is implemented

- **Private browser:** embedded Android WebView, HTTPS-only navigation, back/forward/reload, persistent WebView cookies, URL-or-search navigation, and quick access to ChatGPT, Claude, Grok, DeepSeek, Gemini, LinkedIn, Google Maps, Facebook, Instagram, X and Google News. Google Maps and the social sites can be opened and explored; the supported extraction actions depend on the current page exposing readable DOM content.
- **Manual authentication:** sign in on the real website inside the browser. SynthOS never asks for or stores website passwords.
- **Task queue:** create, run, review, retry and delete tasks; see status and last outcome. Tasks run only after the user starts them and can be paused for manual sign-in/review; interrupted work is marked for review after restart.
- **Browser actions:** capture readable page text and headings; extract visible links; find a phrase and capture surrounding excerpts; scroll up to six times to collect article-like feed cards; prepare text in a visible AI composer without sending it.
- **Explicit send step:** a separately pressed “Send prepared prompt” action clicks a recognizable visible send control, then checks whether the prompt appears in the conversation and the composer clears. If no safe send control is discoverable, SynthOS stops for manual submission. If verification is inconclusive, the task remains in review rather than being reported as complete.
- **Evidence ledger:** saved content includes a source URL, capture time, collection kind, summary and metadata. Search and inspect evidence, open the source, delete individual items, and export/restore JSON backups. Record counts and individual field lengths are bounded. Workspace JSON backups are capped at 40 MB; SynthOS refuses an oversized write/export rather than silently truncating the local workspace.
- **Execution history:** local activity entries record task creation, website navigation, capture, success, block and error events.
- **Privacy and security:** device-authentication gate; AES-256-GCM vault encrypted with an Android Keystore key; `allowBackup=false`; no analytics, cloud backend, API keys or external AI calls.
- **Light, dark and system themes**, accessible labels and large primary touch targets.

## Explicitly out of scope for this build

SynthOS does not control other Android apps, bypass sign-in or access controls, defeat CAPTCHAs, or guarantee automation on every site. It automates only the page inside its own browser. Website terms, account permissions and rate limits still apply. Some sites change their DOM often or restrict automation; review the page before continuing a task.

Website sessions are handled by Android WebView's cookie store. They are not copied into the AES-encrypted SynthOS task/evidence vault. Web content is untrusted: scripts are evaluated against the active page without exposing a JavaScript-to-native bridge, and no credential or cookie values are intentionally extracted.

Transport is HTTPS-only, certificate errors are cancelled, and cleartext traffic is disabled. TLS protocol negotiation is managed by the installed Android WebView and the remote server; WebView does not expose a safe per-app switch that can force TLS 1.3 for every third-party site. This build therefore enforces HTTPS and platform certificate validation, but does not claim TLS-1.3-only connections.

## Requirements

- Android Studio with Android SDK Platform 35 and Build Tools 35.0.0, or the equivalent command-line SDK packages.
- JDK 17.
- Internet access on the first command-line build so the included launcher can fetch and verify Gradle 8.9 (129 MB). Android Studio can also use the project normally.
- An Android device on Android 10 (API 29) or later, with a secure device lock configured. The app uses AndroidX device authentication and offers biometric/device-credential fallback where supported by the platform.

## Build

Open this directory in Android Studio and let Gradle sync, then run the `app` configuration on your phone or select **Build > Build APK(s)**.

Command line, after installing JDK 17 and Android SDK Platform 35 / Build Tools 35.0.0:

```bash
./gradlew --version
./gradlew --no-daemon :app:testDebugUnitTest :app:lintDebug
./gradlew --no-daemon :app:assembleDebug
```

The included `gradlew` / `gradlew.bat` launchers use an installed Gradle 8.9 when available. Otherwise they fetch the official Gradle 8.9 binary distribution, verify its published SHA-256 checksum, and cache it under the user's Gradle directory. Android SDK packages and Maven dependencies still need to be available; the first build therefore requires internet access. The Gradle distribution is not bundled in the ZIP.

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install over USB after enabling Android developer options and USB debugging:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The debug APK is signed with the standard debug certificate so it is immediately installable. It is not a Play Store release artifact.

## GitHub Actions

`.github/workflows/build-apk.yml` runs unit tests and Android lint before building the debug APK, uploads the APK as `synthos-fieldwork-debug-apk`, and attaches it to a GitHub Release for tags matching `v*.*.*`. No signing secrets are needed for the debug artifact.

## Data and recovery

The workspace vault is stored in the app's private files directory. Its contents are encrypted with AES-256-GCM and the key is non-exportable from Android Keystore. The biometric/device-credential gate protects the UI; the data encryption key itself is not cryptographically bound to biometric enrollment.

**Export:** Settings or Evidence → Export JSON backup. The resulting JSON is readable, not encrypted. Choose a secure destination and protect the backup yourself.

**Restore:** Settings → Restore JSON backup. SynthOS asks for confirmation and replaces the current local tasks, evidence and activity. Imports are limited to 40 MB and schema version 1.

Uninstalling the app removes its local vault and WebView app data. Export first if you need to preserve the workspace. Android Keystore keys are intentionally not included in backups.

## Design system

- **Principles:** private by default; inspectable over magical; useful without a model; explicit before consequential actions; graceful failure.
- **Identity:** SynthOS Fieldwork; a quiet, technical workspace for work performed through the browser.
- **Colors:** named light/dark Material 3 tokens in `ui/SynthOsTheme.kt`; indigo primary, teal accent, semantic success/warning/error colors, tested surface roles.
- **Typography:** system font, named scale via Material 3 typography.
- **Spacing:** 4 dp base rhythm (4/8/12/16/20/24/32 dp), 48 dp minimum main control height, 10/16/24 dp corner radii.
- **Components:** Material 3 buttons, fields, cards, chips, dialogs, snackbar, empty/error states and navigation, all themed through the same token source.
- **Motion:** platform-default Material transitions; no custom loops or animation-heavy surfaces.

## Tests

`TaskRulesTest` checks HTTPS normalization, refusal of insecure URLs and embedded credentials, and the required fields for text search and prompt preparation. The Android build also runs the official Android Lint task. The build host used to prepare this source ZIP did not have the Android SDK or Gradle installed, so the full Android compile and these Gradle tests have not been executed in that host; the included GitHub Actions workflow performs them on push. Because websites are mutable third-party systems, live logged-in workflows must be verified on the target device and accounts before relying on them for consequential actions.

## Existing SynthOS extension interoperability

The pre-existing SynthOS extension source and its data contract were not present in the available project files. This build therefore uses a documented local JSON backup format (`schemaVersion: 1`) for task/evidence export and restore; it does not claim a live integration with that extension. A direct bridge can be added when the extension schema or code is available.
