package app.synthos.fieldwork.ui

import android.content.ContentResolver
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Article
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.StopCircle
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Web
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.synthos.fieldwork.automation.TaskRules
import app.synthos.fieldwork.browser.BrowserSession
import app.synthos.fieldwork.browser.TaskCallbacks
import app.synthos.fieldwork.data.AppSnapshot
import app.synthos.fieldwork.data.ActivityRecord
import app.synthos.fieldwork.data.EvidenceRecord
import app.synthos.fieldwork.data.SynthOsViewModel
import app.synthos.fieldwork.data.TaskKind
import app.synthos.fieldwork.data.TaskRecord
import app.synthos.fieldwork.data.TaskStatus
import app.synthos.fieldwork.ui.components.DotLabel
import app.synthos.fieldwork.ui.components.EmptyState
import app.synthos.fieldwork.ui.components.SectionHeading
import app.synthos.fieldwork.ui.components.StatusPill
import app.synthos.fieldwork.ui.components.SurfaceCard
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class AppTab(val label: String) {
    HOME("Home"), BROWSER("Browse"), TASKS("Tasks"), EVIDENCE("Saved"), SETTINGS("Settings")
}

private data class QuickSite(val label: String, val url: String)

private val quickSites = listOf(
    QuickSite("ChatGPT", "https://chatgpt.com/"),
    QuickSite("Claude", "https://claude.ai/new"),
    QuickSite("Grok", "https://grok.com/"),
    QuickSite("DeepSeek", "https://chat.deepseek.com/"),
    QuickSite("Gemini", "https://gemini.google.com/"),
    QuickSite("LinkedIn", "https://www.linkedin.com/feed/"),
    QuickSite("Google Maps", "https://www.google.com/maps"),
    QuickSite("Facebook", "https://www.facebook.com/"),
    QuickSite("Instagram", "https://www.instagram.com/"),
    QuickSite("X", "https://x.com/"),
    QuickSite("Google News", "https://news.google.com/")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SynthOsApp(viewModel: SynthOsViewModel, onLock: () -> Unit) {
    val snapshot by viewModel.snapshot.collectAsState()
    val vaultReady by viewModel.vaultReady.collectAsState()
    val vaultError by viewModel.vaultError.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHost = remember { SnackbarHostState() }
    var tab by remember { mutableStateOf(AppTab.HOME) }
    var evidenceDetail by remember { mutableStateOf<EvidenceRecord?>(null) }
    var deleteEvidence by remember { mutableStateOf<EvidenceRecord?>(null) }
    var deleteTask by remember { mutableStateOf<TaskRecord?>(null) }
    var importUri by remember { mutableStateOf<Uri?>(null) }
    var showImportConfirm by remember { mutableStateOf(false) }
    var importError by remember { mutableStateOf<String?>(null) }
    var lastVisitedHost by remember { mutableStateOf("") }

    fun snack(message: String) { scope.launch { snackbarHost.showSnackbar(message) } }

    val browser = remember(viewModel, context) {
        BrowserSession(
            context = context,
            onVisited = { url, title ->
                val host = runCatching { Uri.parse(url).host.orEmpty().removePrefix("www.") }.getOrDefault("")
                if (host.isNotBlank() && host != lastVisitedHost) {
                    lastVisitedHost = host
                    viewModel.log("Opened $host · ${title.take(100)}")
                }
            },
            onBrowserError = { message -> snack(message) }
        )
    }
    DisposableEffect(browser) { onDispose { browser.dispose() } }

    val callbacks = remember(viewModel, browser) {
        TaskCallbacks(
            onStarted = { viewModel.markTaskRunning(it) },
            onCompleted = { id, evidence, message ->
                viewModel.completeTask(id, evidence, message)
                snack("Task completed. Results saved to Evidence.")
            },
            onNeedsReview = { id, message -> viewModel.markTaskNeedsReview(id, message); snack("Review required: ${message.take(110)}") },
            onFailed = { id, message, blocked -> viewModel.failTask(id, message, blocked); snack(message.take(180)) },
            onEvidence = viewModel::addEvidence,
            onLog = { message, level -> viewModel.log(message, level) }
        )
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) viewModel.exportTo(uri, context.contentResolver) { error -> snack(error ?: "Workspace exported as a JSON backup.") }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importUri = uri
            showImportConfirm = true
        }
    }

    BackHandler(enabled = tab != AppTab.HOME || evidenceDetail != null) {
        when {
            evidenceDetail != null -> evidenceDetail = null
            tab != AppTab.HOME -> tab = AppTab.HOME
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppHeader(onLock = onLock) },
        snackbarHost = { SnackbarHost(snackbarHost) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                val items = listOf(
                    Triple(AppTab.HOME, Icons.Rounded.Home, "Home"),
                    Triple(AppTab.BROWSER, Icons.Rounded.Public, "Browse"),
                    Triple(AppTab.TASKS, Icons.Rounded.TaskAlt, "Tasks"),
                    Triple(AppTab.EVIDENCE, Icons.Rounded.Bookmark, "Saved"),
                    Triple(AppTab.SETTINGS, Icons.Rounded.Settings, "Settings")
                )
                items.forEach { (dest, icon, label) ->
                    NavigationBarItem(
                        selected = tab == dest,
                        onClick = { tab = dest },
                        icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(22.dp)) },
                        label = { Text(label, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(Modifier.fillMaxSize().padding(innerPadding)) {
            if (vaultError != null) {
                VaultWarning(
                    message = vaultError!!,
                    onExport = { exportLauncher.launch("synthos-recovery-${System.currentTimeMillis()}.json") },
                    onImport = { importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }
                )
                EmptyState(
                    title = "Workspace changes are paused",
                    body = "Export any information still visible in memory, or restore a valid SynthOS JSON backup. Browser tasks are paused so results are not silently discarded."
                )
            } else if (!vaultReady) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                when (tab) {
                    AppTab.HOME -> HomeScreen(
                        snapshot = snapshot,
                        activity = snapshot.activity.take(6),
                        onBrowse = { tab = AppTab.BROWSER },
                        onTasks = { tab = AppTab.TASKS },
                        onEvidence = { tab = AppTab.EVIDENCE },
                        onOpenSite = { url -> browser.openQuickLink(url); tab = AppTab.BROWSER },
                        onResumeTask = { task -> runTask(task, browser, callbacks, onOpenBrowser = { tab = AppTab.BROWSER }) }
                    )
                    AppTab.BROWSER -> BrowserScreen(
                        browser = browser,
                        onQuickTask = { kind, query ->
                            val title = TaskRules.guessTitle(kind, query)
                            val error = viewModel.createTask(title, "", kind, query)
                            if (error != null) snack(error) else {
                                val task = viewModel.snapshot.value.tasks.first()
                                runTask(task, browser, callbacks, onOpenBrowser = { tab = AppTab.BROWSER })
                            }
                        },
                        onCancelTask = { browser.cancelPendingTask() },
                        onClearPrompt = { browser.clearPreparedPrompt() }
                    )
                    AppTab.TASKS -> TasksScreen(
                        tasks = snapshot.tasks,
                        activeTaskId = browser.pendingTask?.id,
                        onCreateTask = { title, url, kind, query ->
                            val error = viewModel.createTask(title, url, kind, query)
                            if (error == null) snack("Task saved. Run it when ready.") else snack(error)
                            error == null
                        },
                        onRun = { task -> runTask(task, browser, callbacks, onOpenBrowser = { tab = AppTab.BROWSER }) },
                        onDelete = { deleteTask = it },
                        onOpenBrowser = { tab = AppTab.BROWSER }
                    )
                    AppTab.EVIDENCE -> EvidenceScreen(
                        evidence = snapshot.evidence,
                        onSelect = { evidenceDetail = it },
                        onDelete = { deleteEvidence = it },
                        onExport = { exportLauncher.launch("synthos-backup-${System.currentTimeMillis()}.json") }
                    )
                    AppTab.SETTINGS -> SettingsScreen(
                        themeMode = themeMode,
                        onThemeMode = viewModel::setThemeMode,
                        onExport = { exportLauncher.launch("synthos-backup-${System.currentTimeMillis()}.json") },
                        onImport = { importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream")) },
                        onLock = onLock,
                        onShowMessage = ::snack
                    )
                }
            }
        }
    }

    if (evidenceDetail != null) EvidenceDialog(evidence = evidenceDetail!!, onDismiss = { evidenceDetail = null }, onOpenSource = {
        val url = evidenceDetail?.sourceUrl.orEmpty()
        if (url.startsWith("https://")) { browser.navigate(url); tab = AppTab.BROWSER; evidenceDetail = null }
        else snack("This evidence has no valid HTTPS source URL.")
    }, onDelete = { deleteEvidence = evidenceDetail; evidenceDetail = null })

    if (deleteEvidence != null) {
        ConfirmDialog(
            title = "Delete saved evidence?",
            body = "This removes the captured content from your encrypted workspace. It cannot be undone.",
            confirmLabel = "Delete evidence",
            onDismiss = { deleteEvidence = null },
            onConfirm = { viewModel.deleteEvidence(deleteEvidence!!.id); deleteEvidence = null; snack("Evidence deleted.") }
        )
    }
    if (deleteTask != null) {
        ConfirmDialog(
            title = "Delete task?",
            body = "The task will be removed. Evidence already captured from it remains saved.",
            confirmLabel = "Delete task",
            onDismiss = { deleteTask = null },
            onConfirm = { viewModel.deleteTask(deleteTask!!.id); deleteTask = null; snack("Task deleted.") }
        )
    }
    if (showImportConfirm && importUri != null) {
        ConfirmDialog(
            title = "Replace this workspace?",
            body = "Importing a SynthOS JSON backup replaces tasks, evidence and activity currently stored on this device. Export a backup first if you want to preserve the current data.",
            confirmLabel = "Replace workspace",
            onDismiss = { showImportConfirm = false; importUri = null },
            onConfirm = {
                val uri = importUri!!
                showImportConfirm = false
                importUri = null
                viewModel.importFrom(uri, context.contentResolver) { error ->
                    importError = error
                    snack(error ?: "Backup restored.")
                }
            }
        )
    }
    if (importError != null) {
        AlertDialog(
            onDismissRequest = { importError = null },
            title = { Text("Import failed") },
            text = { Text(importError!!) },
            confirmButton = { TextButton(onClick = { importError = null }) { Text("OK") } }
        )
    }
}

private fun runTask(task: TaskRecord, browser: BrowserSession, callbacks: TaskCallbacks, onOpenBrowser: () -> Unit) {
    if (browser.pendingTask?.id == task.id) {
        onOpenBrowser()
        return
    }
    browser.runTask(task, callbacks)
    onOpenBrowser()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppHeader(onLock: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = SynthTokens.Spacing.pageMargin, vertical = SynthTokens.Spacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(SynthTokens.Spacing.sm))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("SYNTHOS", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground, letterSpacing = 1.3.sp)
                Text("FIELDWORK / WEB AUTOMATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onLock, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) {
                Icon(Icons.Rounded.Lock, contentDescription = "Lock workspace", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun VaultWarning(message: String, onExport: () -> Unit, onImport: () -> Unit) {
    SurfaceCard(modifier = Modifier.padding(horizontal = SynthTokens.Spacing.md, vertical = SynthTokens.Spacing.xs)) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
            Icon(Icons.Rounded.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Workspace storage needs attention", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
                    TextButton(onClick = onExport) { Text("Export visible data") }
                    TextButton(onClick = onImport) { Text("Restore backup") }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    snapshot: AppSnapshot,
    activity: List<ActivityRecord>,
    onBrowse: () -> Unit,
    onTasks: () -> Unit,
    onEvidence: () -> Unit,
    onOpenSite: (String) -> Unit,
    onResumeTask: (TaskRecord) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = SynthTokens.Spacing.pageMargin, vertical = SynthTokens.Spacing.md),
        verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.md)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
                DotLabel("PRIVATE WORKSPACE  ·  LOCAL FIRST")
                Text("Your web, in motion.", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
                Text("Browse with your own sessions. Turn what you find into evidence SynthOS can remember.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs), modifier = Modifier.fillMaxWidth()) {
                MetricCard("Tasks", snapshot.tasks.size.toString(), "${snapshot.tasks.count { it.status in setOf(TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.NEEDS_REVIEW) }} active", Modifier.weight(1f))
                MetricCard("Evidence", snapshot.evidence.size.toString(), "saved locally", Modifier.weight(1f))
                MetricCard("Completed", snapshot.tasks.count { it.status == TaskStatus.COMPLETED }.toString(), "verified", Modifier.weight(1f))
            }
        }
        item {
            SurfaceCard {
                Text("Start with an intent", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(SynthTokens.Spacing.xs))
                Text("SynthOS uses the page you open, records what it observed and keeps every task inspectable.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(SynthTokens.Spacing.md))
                Button(onClick = onBrowse, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Icon(Icons.Rounded.Explore, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open personal browser")
                }
                Spacer(Modifier.height(SynthTokens.Spacing.xs))
                OutlinedButton(onClick = onTasks, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Create a browser task")
                }
            }
        }
        item { SectionHeading("Quick access", "Your browser, your signed-in sessions") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
                quickSites.chunked(2).forEach { rowSites ->
                    Row(horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs), modifier = Modifier.fillMaxWidth()) {
                        rowSites.forEach { site -> QuickSiteCard(site, Modifier.weight(1f)) { onOpenSite(site.url) } }
                        if (rowSites.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionHeading("Continue working", "Tasks that need attention", trailing = { TextButton(onClick = onTasks) { Text("All tasks") } }) }
        val attention = snapshot.tasks.filter { it.status in setOf(TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.NEEDS_REVIEW, TaskStatus.FAILED) }.take(3)
        if (attention.isEmpty()) {
            item { EmptyState("No unfinished tasks", "Create a task when you want SynthOS to capture, inspect or prepare information from a website.") }
        } else {
            items(attention, key = { it.id }) { task -> TaskCompactCard(task = task, onRun = { onResumeTask(task) }) }
        }
        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Bookmark, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Spacer(Modifier.width(SynthTokens.Spacing.sm))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Evidence ledger", style = MaterialTheme.typography.titleMedium)
                        Text("${snapshot.evidence.size} saved observation(s)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onEvidence) { Text("Review") }
                }
            }
        }
        item { SectionHeading("Recent activity", "What SynthOS last observed or completed") }
        if (activity.isEmpty()) {
            item { EmptyState("No activity yet", "Browser navigation and task outcomes will appear here.") }
        } else {
            items(activity, key = { it.id }) { event -> ActivityLine(event) }
        }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun ActivityLine(event: ActivityRecord) {
    val tint = when (event.level.uppercase(Locale.ROOT)) {
        "ERROR" -> MaterialTheme.colorScheme.error
        "WARN" -> MaterialTheme.colorScheme.secondary
        "SUCCESS" -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.primary
    }
    SurfaceCard {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
            Icon(
                imageVector = if (event.level.equals("ERROR", true)) Icons.Rounded.StopCircle else Icons.Rounded.CheckCircle,
                contentDescription = event.level.lowercase(Locale.ROOT),
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(event.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                Text("${event.level} · ${formatDate(event.at)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, hint: String, modifier: Modifier = Modifier) {
    SurfaceCard(modifier) {
        Text(value, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(2.dp))
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun QuickSiteCard(site: QuickSite, modifier: Modifier = Modifier, onClick: () -> Unit) {
    SurfaceCard(modifier = modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
            Icon(Icons.Rounded.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text(site.label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(4.dp))
        Text(Uri.parse(site.url).host.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TaskCompactCard(task: TaskRecord, onRun: () -> Unit) {
    SurfaceCard {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
            Icon(Icons.Rounded.TaskAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(task.lastMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                StatusPill(task.status)
            }
            IconButton(onClick = onRun, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "Open task in browser", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun BrowserScreen(
    browser: BrowserSession,
    onQuickTask: (TaskKind, String) -> Unit,
    onCancelTask: () -> Unit,
    onClearPrompt: () -> Unit
) {
    var address by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var showNewConversationConfirm by remember { mutableStateOf(false) }
    LaunchedEffect(browser.currentUrl) { address = browser.currentUrl }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = SynthTokens.Spacing.sm, vertical = SynthTokens.Spacing.xs), verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Website or search") },
                leadingIcon = { Icon(Icons.Rounded.Public, contentDescription = null) }
            )
            Button(onClick = { browser.navigate(address) }, modifier = Modifier.height(56.dp), contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Go") }
            IconButton(
                onClick = { showNewConversationConfirm = true },
                enabled = browser.canOpenNewConversation,
                modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Start a new AI conversation", tint = if (browser.canOpenNewConversation) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            quickSites.forEach { site ->
                FilterChip(
                    selected = browser.currentUrl.contains(Uri.parse(site.url).host.orEmpty(), ignoreCase = true),
                    onClick = { address = site.url; browser.openQuickLink(site.url) },
                    label = { Text(site.label, maxLines = 1) },
                    leadingIcon = { Icon(Icons.Rounded.Public, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { browser.goBack() }, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(0.dp)) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") }
            OutlinedButton(onClick = { browser.goForward() }, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(0.dp)) { Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Forward") }
            OutlinedButton(onClick = { browser.refresh() }, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(0.dp)) { Icon(Icons.Rounded.Refresh, contentDescription = "Reload") }
            OutlinedButton(onClick = { onQuickTask(TaskKind.CAPTURE_PAGE, "") }, enabled = browser.currentUrl.isNotBlank() && !browser.isLoading, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Icon(Icons.Rounded.Bookmark, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Save") }
            OutlinedButton(onClick = { onQuickTask(TaskKind.EXTRACT_LINKS, "") }, enabled = browser.currentUrl.isNotBlank() && !browser.isLoading, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Icon(Icons.Rounded.Link, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Links") }
        }
        if (browser.pendingTask != null) {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Task ready", style = MaterialTheme.typography.titleSmall)
                        Text(browser.pendingTask?.title.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(if (browser.canContinueTask) "Review the open page, then continue." else "Waiting for page load…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                    }
                    Button(onClick = { browser.continueTask() }, enabled = browser.canContinueTask && !browser.isExecutingTask, modifier = Modifier.height(48.dp), contentPadding = PaddingValues(horizontal = 12.dp)) {
                        if (browser.isExecutingTask) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Continue")
                    }
                    IconButton(onClick = onCancelTask, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) { Icon(Icons.Rounded.Close, contentDescription = "Cancel task") }
                }
            }
        }
        if (browser.preparedPrompt.isNotBlank()) {
            SurfaceCard {
                Text("Prompt prepared · not sent", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("The prompt is in the website composer. Review it before sending.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (browser.sendMessage.isNotBlank()) Text(browser.sendMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
                    Button(onClick = { browser.sendPreparedPrompt() }, enabled = !browser.isSendingPrompt && !browser.isLoading, modifier = Modifier.weight(1f).height(48.dp)) {
                        if (browser.isSendingPrompt) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = null)
                        Spacer(Modifier.width(6.dp)); Text("Send prepared prompt")
                    }
                    OutlinedButton(onClick = onClearPrompt, enabled = !browser.isSendingPrompt, modifier = Modifier.height(48.dp)) { Text("Clear") }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (browser.isLoading) CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
            Text(browser.pageTitle.ifBlank { "No page open" }, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("${browser.progress}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(SynthTokens.Radius.medium)).background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AndroidView(factory = { browser.webView }, modifier = Modifier.fillMaxSize(), update = {})
            if (browser.currentUrl.isBlank()) {
                Column(
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)).padding(SynthTokens.Spacing.lg),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Rounded.Web, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Your private browser", style = MaterialTheme.typography.titleMedium)
                    Text("Open a site above. Log in yourself; SynthOS works inside this session.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 1,
            maxLines = 2,
            label = { Text("Prompt for the current AI chat") },
            placeholder = { Text("Prepare a prompt. It will not be sent yet.") },
            trailingIcon = {
                IconButton(onClick = {
                    if (prompt.isBlank()) return@IconButton
                    onQuickTask(TaskKind.PREPARE_PROMPT, prompt.trim())
                    prompt = ""
                }, enabled = prompt.isNotBlank() && browser.canPreparePrompt) {
                    Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Prepare prompt in page", tint = if (prompt.isNotBlank() && browser.canPreparePrompt) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
        Text(browser.browserMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
    if (showNewConversationConfirm) {
        AlertDialog(
            onDismissRequest = { showNewConversationConfirm = false },
            title = { Text("Start a new conversation?") },
            text = { Text("SynthOS will open this provider's new-chat page. Existing conversations remain on the provider, but an unsent draft on the current page may be lost.") },
            confirmButton = {
                Button(onClick = { showNewConversationConfirm = false; browser.openNewConversation() }) { Text("Open new chat") }
            },
            dismissButton = { TextButton(onClick = { showNewConversationConfirm = false }) { Text("Stay here") } }
        )
    }
}

@Composable
private fun TasksScreen(
    tasks: List<TaskRecord>,
    activeTaskId: String?,
    onCreateTask: (String, String, TaskKind, String) -> Boolean,
    onRun: (TaskRecord) -> Unit,
    onDelete: (TaskRecord) -> Unit,
    onOpenBrowser: () -> Unit
) {
    var showCreate by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("All") }
    val visible = when (filter) {
        "Active" -> tasks.filter { it.status in setOf(TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.NEEDS_REVIEW) }
        "Done" -> tasks.filter { it.status == TaskStatus.COMPLETED }
        "Attention" -> tasks.filter { it.status in setOf(TaskStatus.NEEDS_REVIEW, TaskStatus.FAILED, TaskStatus.BLOCKED) }
        else -> tasks
    }
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = SynthTokens.Spacing.pageMargin, vertical = SynthTokens.Spacing.md), verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
            SectionHeading("Browser tasks", "Small, inspectable actions that you can resume")
            Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Icon(Icons.Rounded.Add, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Create task")
            }
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Active", "Attention", "Done").forEach { label ->
                    FilterChip(selected = filter == label, onClick = { filter = label }, label = { Text(label) })
                }
            }
        }
        if (visible.isEmpty()) {
            EmptyState(
                if (tasks.isEmpty()) "No tasks yet" else "Nothing in this view",
                "Create a task to capture a page, collect links, find a phrase, review a feed or prepare an AI prompt."
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = SynthTokens.Spacing.pageMargin, end = SynthTokens.Spacing.pageMargin, bottom = SynthTokens.Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)
            ) {
                items(visible, key = { it.id }) { task ->
                    TaskCard(
                        task = task,
                        active = task.id == activeTaskId,
                        onRun = { if (task.id == activeTaskId) onOpenBrowser() else onRun(task) },
                        onDelete = { onDelete(task) }
                    )
                }
            }
        }
    }
    if (showCreate) CreateTaskDialog(onDismiss = { showCreate = false }, onCreate = { title, url, kind, query ->
        val created = onCreateTask(title, url, kind, query)
        if (created) showCreate = false
        created
    })
}

@Composable
private fun TaskCard(task: TaskRecord, active: Boolean, onRun: () -> Unit, onDelete: () -> Unit) {
    SurfaceCard {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
            Box(modifier = Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.TaskAlt, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium)
                Text(task.kind.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                if (task.targetUrl.isNotBlank()) Text(task.targetUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (task.query.isNotBlank()) Text(task.query, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(task.lastMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill(task.status)
                    Text(formatDate(task.updatedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = onRun, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) {
                    Icon(if (active) Icons.Rounded.OpenInNew else Icons.Rounded.PlayArrow, contentDescription = if (active) "Continue in browser" else "Run task", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) { Icon(Icons.Rounded.Delete, contentDescription = "Delete task", tint = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun CreateTaskDialog(onDismiss: () -> Unit, onCreate: (String, String, TaskKind, String) -> Boolean) {
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(TaskKind.CAPTURE_PAGE) }
    var kindExpanded by remember { mutableStateOf(false) }
    var validation by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create browser task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
                Text("A task runs in the browser after you review the open page. Leave the URL blank to use the current page.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = title, onValueChange = { title = it; validation = "" }, label = { Text("Task name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = url, onValueChange = { url = it; validation = "" }, label = { Text("Target HTTPS URL (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://example.com") })
                Box {
                    OutlinedButton(onClick = { kindExpanded = true }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Text(kind.label, modifier = Modifier.weight(1f)); Icon(Icons.Rounded.MoreHoriz, contentDescription = "Choose task type")
                    }
                    DropdownMenu(expanded = kindExpanded, onDismissRequest = { kindExpanded = false }) {
                        TaskKind.entries.forEach { option ->
                            DropdownMenuItem(text = { Text(option.label) }, onClick = { kind = option; kindExpanded = false; validation = "" })
                        }
                    }
                }
                Text(kind.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (kind == TaskKind.FIND_TEXT || kind == TaskKind.PREPARE_PROMPT) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it; validation = "" }, modifier = Modifier.fillMaxWidth(),
                        label = { Text(if (kind == TaskKind.FIND_TEXT) "Phrase to find" else "Prompt to prepare") },
                        minLines = if (kind == TaskKind.PREPARE_PROMPT) 3 else 1, maxLines = 5
                    )
                } else {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Notes / query (optional)") }, minLines = 1, maxLines = 3)
                }
                if (validation.isNotBlank()) Text(validation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(onClick = {
                val safeTitle = title.trim().ifBlank { TaskRules.guessTitle(kind, query) }
                val error = TaskRules.validate(safeTitle, url, kind, query)
                if (error != null) validation = error else if (onCreate(safeTitle, url, kind, query)) onDismiss()
            }) { Text("Save task") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun EvidenceScreen(evidence: List<EvidenceRecord>, onSelect: (EvidenceRecord) -> Unit, onDelete: (EvidenceRecord) -> Unit, onExport: () -> Unit) {
    var search by remember { mutableStateOf("") }
    val filtered = evidence.filter { item ->
        search.isBlank() || item.title.contains(search, true) || item.summary.contains(search, true) || item.sourceUrl.contains(search, true) || item.content.contains(search, true)
    }
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = SynthTokens.Spacing.pageMargin, vertical = SynthTokens.Spacing.md), verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
            SectionHeading("Evidence ledger", "Captured content keeps its source and collection context")
            Row(horizontalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = search, onValueChange = { search = it }, modifier = Modifier.weight(1f), singleLine = true,
                    label = { Text("Search saved evidence") }, leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) }
                )
                IconButton(onClick = onExport, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) { Icon(Icons.Rounded.FileDownload, contentDescription = "Export workspace JSON") }
            }
        }
        if (filtered.isEmpty()) {
            EmptyState(if (evidence.isEmpty()) "Nothing captured yet" else "No matching evidence", "Use Capture page, Extract links or Review feed in the browser. Each item stays on this device until you export it.")
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = SynthTokens.Spacing.pageMargin, vertical = SynthTokens.Spacing.xs), verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.sm)) {
                items(filtered, key = { it.id }) { item -> EvidenceCard(item, onSelect = { onSelect(item) }, onDelete = { onDelete(item) }) }
            }
        }
    }
}

@Composable
private fun EvidenceCard(item: EvidenceRecord, onSelect: () -> Unit, onDelete: () -> Unit) {
    SurfaceCard {
        Column(modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = RoundedCornerShape(8.dp)) {
                    Text(item.kind, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
                }
                Spacer(Modifier.weight(1f))
                Text(formatDate(item.capturedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(item.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(item.summary.ifBlank { item.content.take(220) }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Text(item.sourceUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onSelect) { Icon(Icons.Rounded.Description, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Inspect evidence") }
            IconButton(onClick = onDelete, modifier = Modifier.size(SynthTokens.Spacing.minimumTouch)) { Icon(Icons.Rounded.Delete, contentDescription = "Delete evidence", tint = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun EvidenceDialog(evidence: EvidenceRecord, onDismiss: () -> Unit, onOpenSource: () -> Unit, onDelete: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(evidence.title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(modifier = Modifier.heightIn(max = 500.dp), verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.xs)) {
                Text("${evidence.kind} · ${formatDate(evidence.capturedAt)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(evidence.sourceUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (evidence.summary.isNotBlank()) Text(evidence.summary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                SelectionContainer {
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        item { Text(evidence.content, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onOpenSource) { Icon(Icons.Rounded.OpenInNew, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Open source") } },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    )
}

@Composable
private fun SettingsScreen(
    themeMode: String,
    onThemeMode: (String) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onLock: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(SynthTokens.Spacing.pageMargin), verticalArrangement = Arrangement.spacedBy(SynthTokens.Spacing.md)) {
        item { SectionHeading("Settings", "Privacy, appearance and your local workspace") }
        item {
            SurfaceCard {
                Text("Appearance", style = MaterialTheme.typography.titleLarge)
                Text("Choose how SynthOS should look. System follows Android settings.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(SynthTokens.Spacing.sm))
                listOf("SYSTEM" to "System", "LIGHT" to "Light", "DARK" to "Dark").forEach { (value, label) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onThemeMode(value) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = themeMode == value, onClick = { onThemeMode(value) })
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(SynthTokens.Spacing.sm))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("On-device encrypted workspace", style = MaterialTheme.typography.titleMedium)
                        Text("AES-256-GCM data vault. The encryption key is held by Android Keystore. Website cookies stay in the system WebView cookie store.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(SynthTokens.Spacing.sm))
                Text("No analytics, no third-party backend, no API keys and no model download. Page content is saved only when you run a capture task or approve a conversation workflow.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SurfaceCard {
                Text("Backup and restore", style = MaterialTheme.typography.titleLarge)
                Text("Exports contain readable JSON. Choose a destination you trust and protect the file yourself. Import replaces this device's workspace after confirmation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(SynthTokens.Spacing.sm))
                Button(onClick = onExport, modifier = Modifier.fillMaxWidth().height(48.dp)) { Icon(Icons.Rounded.FileDownload, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Export JSON backup") }
                Spacer(Modifier.height(SynthTokens.Spacing.xs))
                OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().height(48.dp)) { Icon(Icons.Rounded.FileUpload, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Restore JSON backup") }
            }
        }
        item {
            SurfaceCard {
                Text("Automation boundaries", style = MaterialTheme.typography.titleLarge)
                Text("SynthOS operates only in its own browser. It supports HTTPS pages, visible-page extraction and a small set of verified actions. It never bypasses sign-in, certificate errors or access controls. Sending a prepared prompt is a separate user action.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(SynthTokens.Spacing.sm))
                OutlinedButton(onClick = onLock, modifier = Modifier.fillMaxWidth().height(48.dp)) { Icon(Icons.Rounded.Lock, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Lock workspace now") }
            }
        }
        item {
            Text("SynthOS Fieldwork · 1.0.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ConfirmDialog(title: String, body: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = { Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun formatDate(timestamp: Long): String = runCatching {
    SimpleDateFormat("MMM d · HH:mm", Locale.getDefault()).format(Date(timestamp))
}.getOrDefault("Recently")
