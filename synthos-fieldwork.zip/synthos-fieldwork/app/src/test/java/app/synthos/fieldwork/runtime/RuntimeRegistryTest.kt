package app.synthos.fieldwork.runtime

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RuntimeRegistryTest {
    @Test fun browserCapabilitiesAreSeparateFromNativeAppCapabilities() {
        val registry = RuntimeRegistry()
        val browser = registry.resolve("runtime.browser")
        val chats = registry.resolve("app.chats")
        assertNotNull(browser)
        assertNotNull(chats)
        assertEquals(RuntimeKind.BROWSER, browser!!.kind)
        assertEquals(RuntimeKind.APP, chats!!.kind)
        assertTrue(registry.can("runtime.browser", "browser.capture_evidence"))
        assertTrue(registry.can("runtime.browser", "browser.submit_prompt"))
        assertTrue(registry.can("runtime.browser", "browser.capture_response"))
        assertTrue(registry.can("runtime.browser", "browser.run_multi_chat_workflow"))
        assertFalse(registry.can("runtime.browser", "entity.propose"))
        assertTrue(registry.can("app.entities", "entity.propose"))
        assertTrue(registry.can("app.entities", "entity.create"))
        assertTrue(registry.can("app.jobs", "job.verify"))
        assertFalse(registry.can("app.entities", "browser.navigate_https"))
    }
}
